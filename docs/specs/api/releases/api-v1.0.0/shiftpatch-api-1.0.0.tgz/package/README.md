# ShiftPatch API contract 1.0.0

OpenAPI 3.1.0 description published as the immutable release `api-v1.0.0`.

- Source repository: https://github.com/maxisun/shifters-specs
- Source commit: `10135556394a5920f0ef0ebd40b9b25d19ee9e0e`

Do not edit files in this package. Change the description in the source repository and publish a new contract version.
